package me.zhulin.shopapi.api;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created By Zhu Lin on 1/2/2019.
 */
public class CartControllerTest {

    @Test
    public void getCart() {
    }
}
