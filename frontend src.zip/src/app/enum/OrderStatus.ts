export enum OrderStatus {
    "New",
    "Finished",
    "Canceled"
}
