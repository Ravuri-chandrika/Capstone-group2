export enum CategoryType {
    "Beds", "Carpets", "Chairs", "Sofas"
}
