import { ProductInfo } from "../models/productInfo";

export class ProductListResponse {
    productList : ProductInfo[]

}

